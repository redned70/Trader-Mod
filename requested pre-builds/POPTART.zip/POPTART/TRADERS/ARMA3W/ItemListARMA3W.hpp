	///////////////////////////////////////////////////////////////////////////////
	// Arma 3 Weapons & Gear  
	///////////////////////////////////////////////////////////////////////////////

	///////////////////////////////////////////////////////////////////////////////
	// Arma 3 Bandannas & Balaclavas (Headgear)
	///////////////////////////////////////////////////////////////////////////////	
	//all now included in default Exile list

	
	///////////////////////////////////////////////////////////////////////////////
	// Dropped by AI or default things not in traders - to be sold only
	///////////////////////////////////////////////////////////////////////////////	
	class FirstAidKit								{ quality = 1; price = 100; };
	class Medikit 									{ quality = 1; price = 100; };
	class MineDetector								{ quality = 1; price = 100; };
	class ToolKit									{ quality = 1; price = 100; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Launchers
	///////////////////////////////////////////////////////////////////////////////	
	class launch_B_Titan_F  						{ quality = 3; price = 7500; sellPrice = 1500; }; 
	class launch_B_Titan_short_F  					{ quality = 3; price = 7500; sellPrice = 1500; }; 
	class launch_I_Titan_F  						{ quality = 3; price = 7500; sellPrice = 1500; }; 
	class launch_I_Titan_short_F  					{ quality = 3; price = 7500; sellPrice = 1500; }; 
	class launch_NLAW_F  							{ quality = 3; price = 7500; sellPrice = 1500; }; 
	class launch_O_Titan_F 							{ quality = 3; price = 7500; sellPrice = 1500; }; 
	class launch_O_Titan_short_F  					{ quality = 3; price = 7500; sellPrice = 1500; }; 
	class launch_RPG32_F   							{ quality = 3; price = 7500; sellPrice = 1500; }; 
	class launch_Titan_F  							{ quality = 3; price = 7500; sellPrice = 1500; }; 
	class launch_Titan_short_F 						{ quality = 3; price = 7500; sellPrice = 1500; }; 	
	
	///////////////////////////////////////////////////////////////////////////////
	// Launcher Ammo
	///////////////////////////////////////////////////////////////////////////////
	class NLAW_F									{ quality = 1; price = 3000; };
	class RPG32_F									{ quality = 1; price = 3000; };
	class RPG32_HE_F                                { quality = 1; price = 3000; };
	class Titan_AA									{ quality = 1; price = 3000; };
	class Titan_AP									{ quality = 1; price = 3000; };	
	class Titan_AT									{ quality = 1; price = 3000; };
	